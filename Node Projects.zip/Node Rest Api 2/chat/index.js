const express = require('express')
const bodyParser = require('body-parser')
const session = require('express-session')
const EventEmitter = require('events').EventEmitter
const emitter = new EventEmitter();
const app = express();

app.set('view engine', 'ejs')
app.use(session({ secret: 'parfait', resave: 'false', saveUninitialized: false }))
app.use(bodyParser.urlencoded({ extended: true }))

app.get('/chat', chatView)
app.get('/updates', sendMessage)
app.post('/message', message)


function chatView(req, res) {
    res.render('index')
}

function sendMessage(req, res) {
    res.setHeader('Content-Type', 'text/event-stream')
    res.setHeader('Connection', 'keep-alive')
    emitter.on('on-message', (data) => {
        console.log(data)
        res.write(`data: ${data}\n\n`)
    })

    res.on('close', ()=>{
        emitter.off('message', ()=>console.log('emiter turned off'))
    })

}

function message(req, res) {
    let { message } = req.body
    let { sender } = req.body
    const data = {message: message, sender: sender}

    emitter.emit('on-message', JSON.stringify(data))
    res.end()
}



app.listen(8000, () => console.log('Listening at http://127.0.0.1:8000'))